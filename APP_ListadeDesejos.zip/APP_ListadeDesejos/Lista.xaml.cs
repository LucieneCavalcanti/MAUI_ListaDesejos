namespace APP_ListadeDesejos;

public partial class Lista
{
    public Lista()
    {
        InitializeComponent();
    }
}