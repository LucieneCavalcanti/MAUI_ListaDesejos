namespace APP_ListadeDesejos;

public partial class Perfil
{
    public Perfil()
    {
        InitializeComponent();
    }
}