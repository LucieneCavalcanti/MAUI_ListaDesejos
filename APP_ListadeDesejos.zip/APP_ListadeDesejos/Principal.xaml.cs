using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APP_ListadeDesejos;

public partial class Principal : ContentView
{
    public Principal()
    {
        InitializeComponent();
    }
}