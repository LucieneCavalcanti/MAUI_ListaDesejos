namespace APP_ListadeDesejos.Classes;

public class Comentario
{
    ItemLista itemLista;
    Usuario usuario;
    string descricao;
    //lista de usuários que curtiram o item
}