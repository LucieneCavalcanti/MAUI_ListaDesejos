namespace APP_ListadeDesejos.Classes;

public class Familiar: Usuario
{
    string grauParentesco;
}