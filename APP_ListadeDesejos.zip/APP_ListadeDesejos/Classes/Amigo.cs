namespace APP_ListadeDesejos.Classes;

public class Amigo : Usuario
{
    string tipoAmizade;
    bool favorito;
}