namespace APP_ListadeDesejos;

public partial class Amigos
{
    public Amigos()
    {
        InitializeComponent();
    }
}